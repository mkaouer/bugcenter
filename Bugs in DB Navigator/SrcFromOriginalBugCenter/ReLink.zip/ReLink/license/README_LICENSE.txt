 
Along with the core Word Vector Tool classes you have received some software
packages. The licenses of these packages are contained in this directory. 
These packages are:

1.Snowball Stemmer package

http://snowball.tartarus.org

2.KEA

http://www.nzdl.org/Kea/

3.Java Wordnet Library

http://jwnl.sf.net

4.WebSphinx

which can be downloaded from

http://www.cs.cmu.edu/~rcm/websphinx/

5.A German Stemmer taken from the Lucene project

http://lucene.apache.org

6. The PDFBOX package

www.pdfbox.org

7. The FONTBOX package

www.fontbox.org

8. The bouncycastle package (used to read encrypted PDF)

http://www.bouncycastle.org


9. WVTool package
http://wvtool.sourceforge.net


